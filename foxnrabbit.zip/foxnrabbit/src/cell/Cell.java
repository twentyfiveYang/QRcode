package cell;

import java.awt.Graphics;
 
public interface Cell {
	void draw(Graphics g, int x, int y, int size);
}
